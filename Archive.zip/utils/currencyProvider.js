const DENOMINATION = '$'

export default DENOMINATION